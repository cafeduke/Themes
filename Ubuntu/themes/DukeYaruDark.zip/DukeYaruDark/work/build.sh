#!/bin/bash -e
BASEDIR=$(dirname $(readlink -f ${0}))
BASENAME=$(basename ${0})
THEMEDIR=$(readlink -f ${BASEDIR}/../)

cd gresource
echo "Generating DukeYaruDark.gresource"
gresource-create DukeYaruDark

echo "Updating DukeYaruDark.gresource"
echo "ls -l ${BASEDIR}/gtk-3.0/gtk.gresource"
cp DukeYaruDark.gresource ${THEMEDIR}/gtk-3.0/gtk.gresource
