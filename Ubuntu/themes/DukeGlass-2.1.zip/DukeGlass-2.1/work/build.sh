#!/bin/bash -e
BASEDIR=$(dirname $(readlink -f ${0}))
BASENAME=$(basename ${0})
THEMEDIR=$(readlink -f ${BASEDIR}/../)

cd gresource
echo "Generating DukeGlass.gresource"
gresource-create DukeGlass

echo "Updating DukeGlass.gresource"
echo "ls -l ${BASEDIR}/gtk-3.0/gtk.gresource"
cp DukeGlass.gresource ${THEMEDIR}/gtk-3.0/gtk.gresource
